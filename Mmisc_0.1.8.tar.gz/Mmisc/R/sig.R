##' Convert numerics to character with a specific number of significant digits.
##'
##' NOTE: this function is only for producting nicely-formatted character data.  DO NOT USE THIS FUNCTION if
##' you want numeric data; use \code{\link{signif}} if you really want numeric data with a certain number
##' of significant digits.
##'
##' @param x numeric
##' @param dig number of significant digits (passed to \code{\link{formatC}} as \code{digits})
##' @param maxex if numeric and the number is represented in scientific notation, numbers with exponents less than \code{maxex} will be converted to be represented without scientific notation
##'
##' @examples
##'
##' x <- rnorm(10)
##'
##' sig(x)
##' sig(x,4)
##'
##' sig(x*1E4)
##' sig(x*1E4, maxex=3)
##' sig(x*1E4, maxex=4)
##' sig(x*1E4, maxex=5)
##' sig(x*1E4, maxex=6)
##'
##' ## DON'T DO THIS:
##' as.numeric(sig(x))
##'
##' ## RATHER, DO THIS:
##' signif(x)
##' @export


sig <- function(x,dig=3,maxex=NULL) {
  namez <- names(x)
  x <- formatC(signif(x,digits=dig), digits=dig, format='g', flag='#')

  if(is.numeric(maxex)) {
    if(dig!=maxex) {
      ex <- "([-]*[0-9]\\.[0-9]+)e([+-][0-9]{2})"
      subit <- grepl(ex,x,perl=TRUE)
      a <- as.numeric(gsub(ex, "\\1", x))
      b <- as.numeric(gsub(ex, "\\2", x))
      subit <- subit & abs(b) < maxex
      x <- ifelse(subit,formatC(signif(as.numeric(x),digits=dig),digits=dig, format="fg",flag="#"),x)
    }
  }
  x <- gsub("\\.$", "", x, perl=TRUE)
  names(x) <- namez
  return(x)
}
