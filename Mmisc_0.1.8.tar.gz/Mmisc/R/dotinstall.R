require(tools)

##' dotinstall
##' @rdname dotinstall
##' @name dotinstall
##' 
NULL

GLOBAL <- list()
GLOBAL$URL <- list(
  audited ="https://metrumrg-soft.s3.amazonaws.com/audited/audited_1.9.tar.gz",
  fork = "https://metrumrg-soft.s3.amazonaws.com/fork/fork_1.2.4.tar.gz",
  review = "https://metrumrg-soft.s3.amazonaws.com/review/review_2.5.tar.gz",
  qapply = "https://bitbucket.org/metrumrg/qapply/downloads/qapply_1.35.tar.gz"
)

##' Get special packages.
##' 
##' @param pkgname name of package to get
##' @param pkg project package directory
##' @param lib project lib directory 
##' @param url complete url to source package
##' @param ... passed along to other functions
##' @name   special_packages
##' @rdname special_packages
##' 
##' @details 
##' Valid package names for \code{.install_URL} include \code{audited},
##' \code{fork}, \code{review}, \code{qapply}.
##' 
##' @examples
##' \dontrun{
##'    .install_audited()
##'    .install_fork()
##'    .install_review()
##'    .install_metrumrg()
##' }
##' 
NULL

##' @rdname special_packages
##' @export
.install_audited <- function(...) .install_URL("audited",...)

##' @rdname special_packages
##' @export
.install_fork <- function(...) .install_URL("fork", ...)

##' @rdname special_packages
##' @export
.install_review <- function(...) .install_URL("review", ...)

##' @rdname special_packages
##' @export
.install_qapply <- function(...) .install_URL("qapply", ...)

##' @rdname special_packages
##' @export
.install_metrumrg <- function(pkg="pkg",lib="lib",root=.def_root()) {
  pkg <- normalizePath(file.path(root,pkg))
  lib <- normalizePath(file.path(root,lib))
  install.packages('metrumrg', repos=c('http://R-Forge.R-project.org','https://cran.rstudio.org'),
                   type="source",destdir=pkg,lib=lib) 
  
}

##' @rdname special_packages
##' @export
.install_URL <- function(pkgname,pkg="pkg",lib="lib",url=NULL) {

  if(is.null(url)) {
    url <- GLOBAL[["URL"]][[pkgname]]
  }
  file <- basename(url)
  dest <- file.path(normalizePath(pkg),file)
  download.file(url, destfile=dest)
  install.packages(dest,type="source",repos=NULL,lib=normalizePath(lib),
                   INSTALL_opts="--no-multiarch")
}

.PACKAGEFILE <- function(pkg) file.path(pkg,"PACKAGES")

as.cvec <- function(x) {
  if(length(x)>1) return(x)
  if(!any(grepl(",",x))) return(x)
  x <- gsub("\\s*", "",x)
  unlist(strsplit(x,","))
}

.def_root <- function() dirname(.libPaths()[1])

##' Ignore lib directory.
##' 
##' @param root project root directory
##' @param lib installed packages directory
##' @param ci run svn ci?
##' @rdname ignore_libs
##' @export
.ignore_libs <- function(root=.def_root(),lib="lib", ci=FALSE) {
  
  if(!missing(root) & file.exists(root)) {
    lib <- file.path(root,"lib")
  }
  if(!file.exists(lib)) stop("Could not find lib directory")
  libs <- list.files(lib, full.names=FALSE)
  libs <- c(libs, "ignore.txt", "PACKAGES", "PACKAGES.gz")
  writeLines(con=file.path(lib,"ignore.txt"), libs)
  setwd(lib)
  system("svn propset svn:ignore -F ignore.txt .")
  setwd("..")
  if(ci) system("svn ci -m \"ignoring libs\" .")
}

##' Write Packages.
##' 
##' @param pkg package directory
##' @param ... passed to \code{tools::write_PACKAGES}
##' @rdname write_packages
##' @export
.write_packages <- function(pkg=normalizePath("pkg"),...) tools::write_PACKAGES(pkg,...)


##' Get available packages.
##' 
##' @param pkg zipped packages directory
##' @param which column names to return from \code{\link{available.packages}}
##' @param write.first call \code{\link{write_PACKAGES}} first?
##' @param ... passed to \code{\link{write_PACKAGES}}
##' @rdname get_available
##' @export 
.get_available <- function(pkg="pkg",which=c("Package","Version"),write.first=FALSE,...) {
  which <- unique(c(which,"Package","Version"))
  pkg <- normalizePath(pkg)
  if(write.first) .write_packages(pkg,...)
  f <- as.data.frame(available.packages(contriburl=.my_cran(pkg)),stringsAsFactors=FALSE)[,which,drop=FALSE]
  if(nrow(f)==0) {
    message("No packages available")
    return(data.frame(Package="a", Version="b")[0,])
  }
  f$name <- paste0(f$Package, "_",f$Version)
  return(f)
}
##' Get installed packages
##' 
##' @param lib library directory
##' @param which columns from \code{\link{installed.packages}} to return
##' @rdname get_installed
##' @export
##' 
.get_installed <- function(lib="lib",which=c("Package", "Version")) {
  which <- unique(c(which,"Package","Version"))
  lib <- normalizePath(lib)
  f <- as.data.frame(installed.packages(lib.loc=lib),stringsAsFactors=FALSE)[,which,drop=FALSE]
  if(nrow(f)==0) {
    message("No packages installed")
    return(data.frame(Package="a", Version="b")[0,])
  }
  f$name <- paste0(f$Package, "_",f$Version)
  return(f)
}


.my_cran <- function(pkg) {
  paste0("file://", normalizePath(pkg)) 
}


##' Install locally archived packages.
##' 
##' @param ... quoted names of local packages to install
##' @param root project root directory
##' @param lib installed packages directory
##' @param pkg zipped packages directory
##' @param verbose not used
##' @param force force install if the package is already found by \code{.get_installed}
##' @param write.first passed to \code{.get_available}
##' @rdname install_local
##' @export
.install_local <- function(...,root=.def_root(),lib="lib", pkg="pkg",force=FALSE, write.first=FALSE,
                           verbose=FALSE,type="source", drop=character(0),dry.run=FALSE) {
  
  pkgs <- list(...)
  pkgs <- unlist(lapply(pkgs, as.cvec))
  pkgs <- setdiff(pkgs,drop)
  
  scriptDir <- root
  pkg <- normalizePath(file.path(scriptDir, pkg))
  lib <- normalizePath(file.path(scriptDir, lib))
  
  if(!file.exists(pkg)) stop("Could not find pkg directory")
  if(!file.exists(lib)) stop("Could not find lib directory")
  
  home <- Sys.getenv("HOME")
  Sys.setenv(HOME="")
  on.exit(Sys.setenv(HOME=home))
  
  .libPaths(lib)
  require(tools)
  
  av <- .get_available(pkg,write.first=write.first)
  i <- .get_installed(lib)
  
  na <- character(0)
  
  cat("\n\nFound ", nrow(av), " packages in local repository\n")
  cat("      ", nrow(i), " packages are already installed\n")
  
  if(!force) {
    f <- subset(av, !is.element(name,i$name))
  } else {
    f <- av
  }
  N <- nrow(f)
  
  cat("      ", N, " packages to install\n")
  
  if(N==0 & !is.character(pkgs)) {
    message("No new packages to install\n   consider re-running after .write_packages().")
    return(invisible(NULL))
  }
  
  f <- f[,"Package"]
  
  if(dry.run) {
    message("Dry run ... returning")
    return(invisible(NULL))
  }
  
  if(is.character(pkgs)) {
    
    f <- f[f %in% pkgs]
    na <- setdiff(pkgs,av$Package)
    if(length(na)>0) {
      message("Packages not available:\n", paste(na, collapse="\n")) 
    }
    
    if(length(f)==0) {
      message("No new packages to install\n   consider re-running after .write_packages().")
      return(invisible(NULL))
    }
    
    cat("Installing ", paste(pkgs, collapse=" "), "\n\n")
  } else {
    if(force) cat("Installing available packages in local repository...\n\n")
    if(!force) cat("Installing uninstalled packages in local repository...\n\n")
  }
  install.packages(f,contriburl=.my_cran(pkg),type=type, lib=lib, INSTALL_opts="--no-multiarch")
}


##' Install packages from CRAN or other CRAN mirror.
##' 
##' @param ... character names of R packages to install
##' @param root project root directory
##' @param repos repository from which to get packages
##' @param lib installed packages directory
##' @param pkg zipped packages directory
##' @param pkg.win directory for storing win.binary versions of packages
##' @param get.win logical; if \code{TRUE}, win.binary packages will be retreived
##' @param get.deps force install of package dependencies
##' @rdname install_cran
##' @export
##' @details
##' The R-Forge repository location \code{http://R-Forge.R-project.org} is automatically appended to \code{repos}.
.install_cran <- function(..., root=.def_root(),repos="http://cran.us.r-project.org",get.deps=FALSE,
                          lib="lib", pkg="pkg",type="source", pkg.win=file.path(pkg,"win"), get.win=FALSE) {
  
  pkgs <- list(...)
  pkgs <- unlist(lapply(pkgs, as.cvec))
  
  repos <- c(repos, "http://R-Forge.R-project.org")
  
  if(get.win & !file.exists(pkg.win)) dir.create(pkg.win)
  #stop(paste("Windows binary directory", pkg.win, "doesn't exist."))
  
  pkg <- normalizePath(path.expand(file.path(root,pkg)),mustWork=FALSE)
  lib <- normalizePath(path.expand(file.path(root,lib)),mustWork=FALSE)
  if(!file.exists(pkg)) stop("Could not find pkg directory ", pkg)
  if(!file.exists(lib)) stop("Could not find lib directory ", lib)
  
  cat("Installing: ", paste( pkgs, collapse=", "), "\n\n")
  cat("library location: ", lib, "\n")
  cat("destdir: ", pkg, "\n\n")
  
  home <- Sys.getenv("HOME")
  Sys.setenv(HOME="")
  on.exit(Sys.setenv(HOME=home))
  
  if(length(pkgs) <1) stop("Please specify packages to install from CRAN")
  
  .libPaths(lib)
  require(tools)
  
  
  if(get.deps) {
    pkgs <- .pkg_list(pkgs)
    if(length(pkgs$dep)>0 ) {
      cat("dotinstall found these dependencies:\n")
      cat(paste("   ", pkgs$dep), sep="\n")
      cat("\n")
      pkgs <- sort(unique(unlist(pkgs)))
    } else {
      pkgs <- pkgs$pkg 
    }
  }
  
  
  install.packages(pkgs,repos=repos, type=type, destdir=pkg,lib=lib,INSTALL_opts="--no-multiarch")
  
  if(get.win) {
    cat("\n\nDownloading windows binaries ...")
    if(!file.exists(pkg.win)) stop(paste("Directory ", pkg.win, " doesn't exist"))
    .get_win_binaries(pkgs, destdir=pkg.win, repos=repos)
  }
  return(invisible(NULL))
}

##' Return a matrix of locally-available packages.
##' 
##' @param root root project directory 
##' @param pkg zipped packages directory
##' @param ... passed along
##' @rdname local_repos
##' @export
.local_repos <- function(root=.def_root(), pkg="pkg",...) {
  
  if(!missing(root) & file.exists(root)) {
    pkg <- file.path(root,pkg)
  } else {
    scriptDir <- root
    pkg <- file.path(scriptDir, pkg)
  }
  
  if(!file.exists(pkg)) stop("Could not find pkg directory")
  
  require(tools)
  
  f <- .get_available(pkg, which=c("Package", "Version"))
  
  N <- nrow(f)
  
  cat("\nFound ", N, " packages in local repository")
  return(f)
}


##' Get a matrix listing locally-installed packages.
##' 
##' @param root project root directory
##' @param lib installed packages directory
##' @param ... passed along
##' @rdname local_installed
##' @export
.local_installed <- function(root=.def_root(),lib="lib",...) {
  if(!missing(root) & file.exists(root)) {
    lib <- file.path(root,lib)
  } else {
    scriptDir <- root
    lib <- file.path(scriptDir, lib)
  }
  
  if(!file.exists(lib)) stop("Could not find lib directory")
  
  .libPaths(lib)
  require(tools)
  
  f <- .get_installed(lib)
  
  N <- nrow(f)
  
  cat("\nFound ", N, " packages installed locally\n\n")
  print(f)
  return(invisible(as.data.frame(f,stringsAsFactors=FALSE)))
  
}

.pkg_list <- function(x,base=FALSE,...) {
  force(x)
  x <- .no_base(x,...)
  y <- .get_dependencies(x,...)
  if(!base) {
    x <- sort(unique(.no_base(x,...)))
    y <- sort(unique(.no_base(y,...)))
  }
  return(list(pkg=x, dep=y))
}

##' Look up package dependencies.
##' 
##' @param x character vector of package names
##' @param which passed to \code{\link{package_dependencies}}
##' @param db passed to \code{\link{package_dependencies}}
##' @rdname get_dependencies
##' @export
.get_dependencies <- function(x, which=c("Depends", "Imports", "LinkingTo"), db=NULL,...) {
  require(tools)
  if(is.null(db)) db <- utils::available.packages()
  x <- .no_base(x)
  return(tools::package_dependencies(x, which=which,recursive=TRUE, db=db))
}

.get_win_binaries <- function(x,destdir='.',base=FALSE,...) {
  if(base) x <- .no_base(x)
  utils::download.packages(x, destdir=destdir, type="win.binary",...) 
}

.no_base <- function(x,...) {
  y <- names(which(utils::installed.packages()[, "Priority"] == "base"))
  setdiff(unlist(x), y) 
}

.get_audited <- function(pkg,lib,install=TRUE) {
  dest <- normalizePath(file.path(pkg,"audited_1.9.tar.gz"))
  download.file("http://metrumrg-soft.s3.amazonaws.com/audited/audited_1.9.tar.gz",
                destfile=dest) 
  if(install) install.packages(dest, lib=lib,type="source", repos=NULL, INSTALL_opts="--no-multiarch")
}


