##' Create a subversion repository on mc1 and set permissions
##' 
##' \itemize{
##'   \item Created May 12, 2016
##' }
##' 
##' @param repo_name Repository name, to be placed under \code{repo_path} on \code{repo_server}
##' @param repo_server Remote server hosting code repositories
##' @param repo_path Path on remote server in which to place \code{repo_name}
##' @param create_local Create a checkout locally and populate per SOP
##'
##' @details
##' 
##' @examples
##' svnadmin_create("test-repo") 
##' @export

svnadmin_create <- function(repo_name,  repo_server="mc1.metrumrg.com", 
                            repo_path="/common/repo", create_local=T){
  if(is.null(repo_name)) return(cat(file=stderr(), "Specify a repository"))
  create_command <- sprintf("svnadmin create %s/%s", repo_path, repo_name)
  
  out <- system(sprintf("ssh %s '%s;ls -alt %s/%s'",
                 repo_server,create_command,
                 repo_path,repo_name),
         intern=T)
  if(create_local){
    if(!any(grepl("Mmisc",rownames(installed.packages())))) return(print("Mmisc pkg not found"))
    system(sprintf("svn co svn+ssh://%s/%s/%s",repo_server,repo_path,repo_name))
    file.copy(system.file("template.zip", package="Mmisc"),sprintf("./%s",repo_name))
    system(sprintf("unzip %s/template.zip -d %s", repo_name, repo_name))
    system(sprintf("mv %s/pkg/inst/template/* %s", repo_name, repo_name, repo_name))
    unlink(sprintf("%s/pkg",repo_name),recursive=T)
    unlink(sprintf("%s/template.zip",repo_name))
  }
  return()
}
